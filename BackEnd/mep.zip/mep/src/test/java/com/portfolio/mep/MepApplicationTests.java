package com.portfolio.mep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MepApplicationTests {

	@Test
	void contextLoads() {
	}

}
